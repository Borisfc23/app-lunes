package com.synopsis.infraestructura.keycloackAdapter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloackAdapterApplicationTests {

	@Test
	void contextLoads() {
	}

}

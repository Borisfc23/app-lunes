package com.synopsis.infraestructura.keycloackAdapter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloackAdapterApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeycloackAdapterApplication.class, args);
	}

}

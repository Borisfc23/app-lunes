package com.synopsis.capacitacion.transactions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
